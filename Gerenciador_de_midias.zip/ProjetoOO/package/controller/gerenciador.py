from package.models.modelos import ItemDeMidia, Livro, Filme, Revista, ValidadorDeDados
from package.controller.db.serialobjson import MidiaJSON
from typing import List

# CLASSE DE LÓGICA
class GerenciadorDeMidia: 
    def __init__(self):
        self.db = MidiaJSON()
        self._colecao: List[ItemDeMidia] = self.db.carregar()
    
    def adicionar_item(self, item: ItemDeMidia) -> bool:
        
        if not isinstance(item, (Livro, Revista, Filme)):
             return False

        if not ValidadorDeDados.validar_titulo(item.titulo):
             return False

        if not ValidadorDeDados.validar_ano_publicacao(item.ano_publicacao):
             return False

        self._colecao.append(item)
        self.db.salvar(self._colecao)
        return True
    
    def remover_item(self, id_midia: str) -> bool:

        removido = False
        nova_colecao = []
        for item in self._colecao:
            if item._id != id_midia:
                nova_colecao.append(item)
            else:
                removido = True
        
        self._colecao = nova_colecao
        
        if removido:
            self.db.salvar(self._colecao)
        
        return removido
    

    def atualizar_item(self, item_novo: ItemDeMidia) -> bool:
        
        if not ValidadorDeDados.validar_titulo(item_novo.titulo):
             return False

        if not ValidadorDeDados.validar_ano_publicacao(item_novo.ano_publicacao):
             return False

        item_antigo_encontrado = False
        nova_colecao = []
        
        for item in self._colecao:
            if item._id != item_novo._id:
                nova_colecao.append(item)
            else:
                item_antigo_encontrado = True
                
        if not item_antigo_encontrado:
            return False 


        nova_colecao.append(item_novo)
        self._colecao = nova_colecao
        
        self.db.salvar(self._colecao)
        return True



    def get_colecao_para_gui(self) -> List[ItemDeMidia]:

         return self._colecao
    
    def get_info_id(self, id_midia: str) -> str:
        for i in self._colecao:
            if i._id == id_midia:
                return i.get_info()
        return f"Nenhuma mídia com o ID {id_midia} foi encontrada"
    
    def buscar_classe_por_id(self, id_midia: str) -> ItemDeMidia | None:
        for i in self._colecao:
            if i._id.lower() == id_midia.lower():
                return i
        return None

    def buscar_por_titulo(self, input_titulo: str) -> List[ItemDeMidia]:
        resultados = []
        input_titulo_lower = input_titulo.lower()

        for i in self._colecao:
            titulo_lower = i.titulo.lower()
            if input_titulo_lower in titulo_lower:
                resultados.append(i)

        return resultados
    
    def salvar_colecao_manualmente(self):
        self.db.salvar(self._colecao)