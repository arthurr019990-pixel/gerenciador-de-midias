import json
import os
from package.models.modelos import ItemDeMidia, Livro, Revista, Filme



class MidiaJSON:
    def __init__(self, file_name = "package/controller/db/data/colecao_de_midias.json"):
        
        self.__filename = file_name
    
    def salvar(self, colecao):
        lista_de_midias = [i.to_dict() for i in colecao]

        try:
            diretorio = os.path.dirname(self.__filename)
            if diretorio and not os.path.exists(diretorio):
                os.makedirs(diretorio)

            with open(self.__filename, "w", encoding="utf-8") as f:
                json.dump(lista_de_midias, f, indent=4, ensure_ascii=False)
            return True
        except Exception as e:  
            print(f"Erro ao salvar dados JSON: {e}")
            return False
    
    
    def carregar(self):

        try:
            with open(self.__filename, "r", encoding="utf-8") as f:
                lista_de_midias = json.load(f)
        except FileNotFoundError:
            print(f"Arquivo de dados '{self.__filename} não encontrado. Iniciando coleção vazia")
            return []
        except Exception as e:
            print(f"Erro ao carregar os dados ({e}). Esvaziando a coleção")
            return []
        
        midias_reconstruidas = []
        max_id = 0
        
        for i in lista_de_midias:
            tipo = i.get("tipo")
            id_antigo = i.get("id")
            midia = None

            if id_antigo and len(id_antigo) > 3:
                try:
                    id_num_str = id_antigo[3:]
                    id_num = int(id_num_str)
                except ValueError:
                    pass
            
            if tipo == "Livro":
                midia = Livro(i["titulo"], i["ano_publicacao"], i["autor"], id_antigo)
            elif tipo == "Filme":
                midia = Filme(i["titulo"], i["ano_publicacao"], i["diretor"], i["nacionalidade"], id_antigo)
            elif tipo == "Revista":
                midia = Revista(i["titulo"], i["ano_publicacao"], i["editora"], i["edicao"], id_antigo)
            
            if midia and i.get("consumido"):
                midia.marcar_como_lido()
            
            if midia:
                midias_reconstruidas.append(midia)
            
        if max_id > 0:
            ItemDeMidia.restaurar_contador(max_id)
            
        return midias_reconstruidas