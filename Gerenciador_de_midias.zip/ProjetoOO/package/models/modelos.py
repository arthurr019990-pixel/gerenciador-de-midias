import datetime

# CLASSE BASE
class ItemDeMidia:

    _contador_id = 0

    def __init__(self, titulo: str, ano_publicacao: int, id_antigo: str = None):

        self.titulo = titulo
        self.ano_publicacao = ano_publicacao
        self._lido = False
        self._id = None

      
        if id_antigo:
            self.restaurar_id(id_antigo)
        else:
            self._id = self._gerar_id_unico(self._get_prefixo())


    @classmethod
    def _gerar_id_unico(cls, prefixo):

        cls._contador_id += 1
        return f"{prefixo}{cls._contador_id}"
    
    @classmethod
    def restaurar_contador(cls, max_id):

        if max_id >= cls._contador_id:
            cls._contador_id = max_id
    
    def restaurar_id(self, id_antigo):
 
        self._id = id_antigo


    def marcar_como_lido(self):
        self._lido = True
    
    def esta_consumido(self):
        return self._lido
    

    def get_info(self) -> str:
        status = "CONSUMIDO" if self._lido else "PENDENTE"
        return f"Mídia: {self.titulo} (Ano: {self.ano_publicacao}) - Status: {status}"
    
    def to_dict(self): 
        return {
            "id": self._id, 
            "tipo": self.__class__.__name__,
            "titulo": self.titulo,
            "ano_publicacao": self.ano_publicacao,
            "consumido": self._lido
        }

    def _get_prefixo(self):
        raise NotImplementedError("Subclasse deve implementar o prefixo da mídia.")


# CLASSE AUXILIAR
class ValidadorDeDados:
    
    @staticmethod
    def validar_titulo(titulo: str) -> bool:
        return len(titulo.strip()) > 0 and len(titulo) <= 200

    @staticmethod
    def validar_ano_publicacao(ano_publicacao: int) -> bool:
        ano_atual = datetime.date.today().year
        return isinstance(ano_publicacao, int) and 1500 <= ano_publicacao <= ano_atual

# CLASSES FILHAS
class Livro(ItemDeMidia):

    def __init__(self, titulo: str, ano_publicacao: int, autor: str, id_antigo: str = None):
        self.autor = autor

        super().__init__(titulo, ano_publicacao, id_antigo) 

    def get_info(self) -> str:
        status = "LIDO" if self._lido else "NÃO LIDO"
        return (f"LIVRO: {self.titulo} - Autor: {self.autor} " 
                f"(Ano: {self.ano_publicacao}, ID: {self._id}) - Status: {status}")
    
    def _get_prefixo(self):
        return "LVR"

    def to_dict(self):
        data = super().to_dict()
        data["autor"] = self.autor 
        return data

        

class Revista(ItemDeMidia):


    def __init__(self, titulo: str, ano_publicacao: int, editora: str, edicao: str, id_antigo: str = None):
        self.editora = editora
        self.edicao = edicao
        super().__init__(titulo, ano_publicacao, id_antigo)

    def get_info(self) -> str:
        status = "LIDA" if self._lido else "NÃO LIDA"
        return (f"REVISTA: {self.titulo} (ID: {self._id}) - Editora: {self.editora}" 
                f" (Edição: {self.edicao}, Ano: {self.ano_publicacao}) - Status: {status}")

    def _get_prefixo(self):
        return "RVS" 

    def to_dict(self):
        data = super().to_dict()
        data["editora"] = self.editora 
        data["edicao"] = self.edicao   
        return data

class Filme(ItemDeMidia): 


    def __init__(self, titulo: str, ano_publicacao: int, diretor: str, nacionalidade: str, id_antigo: str = None):
        self.diretor = diretor
        self.nacionalidade = nacionalidade
        super().__init__(titulo, ano_publicacao, id_antigo)
    
    def get_info(self) -> str:
        status = "VISTO" if self._lido else "NÃO VISTO"
        return (f"FILME: {self.titulo} (ID: {self._id})- Diretor: {self.diretor}" 
                f" (Nacionalidade: {self.nacionalidade}) - Status: {status}")
    
    def _get_prefixo(self):
        return "FLM"

    def to_dict(self):
        data = super().to_dict()
        data["diretor"] = self.diretor         
        data["nacionalidade"] = self.nacionalidade 
        return data
    
def atualizar_item(self, item_novo: ItemDeMidia) -> bool:
    """Substitui o item antigo pelo novo objeto (item_novo) com o mesmo ID."""
    
    # 1. Encontra e remove o item antigo
    item_antigo_encontrado = False
    nova_colecao = []
    
    for item in self._colecao:
        if item._id != item_novo._id:
            nova_colecao.append(item)
        else:
            item_antigo_encontrado = True
            
    if not item_antigo_encontrado:
        return False # Não encontrou o item para atualizar

    # 2. Adiciona o item novo (com o mesmo ID)
    nova_colecao.append(item_novo)
    self._colecao = nova_colecao
    
    # 3. Salva a alteração
    self.db.salvar(self._colecao)
    return True
