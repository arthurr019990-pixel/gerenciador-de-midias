import tkinter as tk
from tkinter import messagebox, simpledialog, ttk
from package.controller.gerenciador import GerenciadorDeMidia
from package.models.modelos import Livro, Revista, Filme, ItemDeMidia

# Instância ÚNICA do Modelo
MIDIA_MANAGER = GerenciadorDeMidia()

class GerenciadorGUI:
    def __init__(self, master):
        self.master = master
        master.title("Gerenciador de Mídias (GUI)")

        # Variáveis de controle de estado (Inputs e Tipo)
        self.inputs = {}
        self.tipo_var = tk.StringVar(master)

        # 1. Configura a UI Principal
        self._configurar_layout_principal()
        
        # Carrega os dados iniciais
        self.atualizar_lista()

    def _configurar_layout_principal(self):
        """Define os frames, botões de ação e a tabela principal."""
        
        # --- Frames (Organização) ---
        frame_acoes = tk.Frame(self.master)
        frame_acoes.pack(pady=10)

        frame_lista = tk.Frame(self.master)
        frame_lista.pack(pady=10, padx=10, fill='both', expand=True)

        # --- Botões de Ação ---
        tk.Button(frame_acoes, text="Adicionar Mídia", command=self.abrir_janela_adicionar).pack(side=tk.LEFT, padx=5)
        tk.Button(frame_acoes, text="Remover por ID", command=self.remover_midia_dialog).pack(side=tk.LEFT, padx=5)
        tk.Button(frame_acoes, text="Marcar Lido/Visto", command=self.marcar_como_consumido_selecionado).pack(side=tk.LEFT, padx=15)
        
        # --- Tabela de Listagem (Treeview) ---
        self.tree = ttk.Treeview(frame_lista, 
                                 columns=('ID', 'Tipo', 'Título', 'Ano', 'Status'), 
                                 show='headings')
        self.tree.pack(side='left', fill='both', expand=True)
        
        # Configuração das colunas e scrollbar (Omitida para simplificar a leitura, mas mantém a função)
        self.tree.heading('ID', text='ID'); self.tree.column('ID', width=80, anchor=tk.CENTER)
        self.tree.heading('Tipo', text='Tipo'); self.tree.column('Tipo', width=80, anchor=tk.CENTER)
        self.tree.heading('Título', text='Título'); self.tree.column('Título', width=200)
        self.tree.heading('Ano', text='Ano'); self.tree.column('Ano', width=50, anchor=tk.CENTER)
        self.tree.heading('Status', text='Status'); self.tree.column('Status', width=70, anchor=tk.CENTER)

        vsb = ttk.Scrollbar(frame_lista, orient="vertical", command=self.tree.yview)
        vsb.pack(side='right', fill='y')
        self.tree.configure(yscrollcommand=vsb.set)
        
        # Evento de duplo clique para Edição
        self.tree.bind('<Double-1>', self.on_item_double_click) 

    # --- CRUD: READ (Leitura) ---

    def atualizar_lista(self):
        """Lê os dados do Gerenciador e atualiza a Treeview."""
        for item in self.tree.get_children():
            self.tree.delete(item)
            
        colecao = MIDIA_MANAGER.get_colecao_para_gui()
        
        if colecao:
            for midia in colecao:
                tipo = midia.__class__.__name__
                status = "LIDO/VISTO" if midia.esta_consumido() else "PENDENTE"
                self.tree.insert('', tk.END, values=(midia._id, tipo, midia.titulo, midia.ano_publicacao, status))
        else:
             self.tree.insert('', tk.END, values=('','','Nenhuma mídia encontrada.','',''))
             
    # --- CRUD: DELETE (Remoção) ---

    def remover_midia_dialog(self):
        """Abre a caixa de diálogo para obter o ID e remover item."""
        id_midia = simpledialog.askstring("Remover Mídia", "Digite o ID da mídia a ser removida:", parent=self.master)
        
        if id_midia:
            if MIDIA_MANAGER.remover_item(id_midia):
                messagebox.showinfo("Sucesso", f"Mídia {id_midia} removida!")
                self.atualizar_lista() 
            else:
                messagebox.showerror("Erro", f"Mídia com ID {id_midia} não encontrada.")
                
    # --- CRUD: UPDATE (Marcar Consumido) ---

    def marcar_como_consumido_selecionado(self):
        """Marca o item selecionado como lido/visto."""
        try:
            item_id_selecionado = self.tree.selection()[0]
            id_midia = self.tree.item(item_id_selecionado, 'values')[0]
            
            midia = MIDIA_MANAGER.buscar_classe_por_id(id_midia)
            
            if midia and not midia.esta_consumido():
                midia.marcar_como_lido()
                MIDIA_MANAGER.atualizar_item(midia) # O update salva a coleção
                
                messagebox.showinfo("Sucesso", f"'{midia.titulo}' marcado como lido/visto!")
                self.atualizar_lista()
            elif midia and midia.esta_consumido():
                messagebox.showinfo("Status", f"'{midia.titulo}' já está marcado como lido/visto.")
            else:
                messagebox.showerror("Erro", "Selecione uma mídia válida.")
                
        except IndexError:
            messagebox.showerror("Erro", "Selecione uma mídia na lista.")

    def on_item_double_click(self, event):
        """Obtém o item selecionado e abre a janela de edição."""
        try:
            item = self.tree.selection()[0]
            id_midia = self.tree.item(item, 'values')[0] 
            self._abrir_form_midia(id_midia=id_midia)
            
        except IndexError:
            pass # Ignora duplo clique sem seleção

    # --- CRUD: CREATE/UPDATE (Formulário) ---
    
    def abrir_janela_adicionar(self):
        """Função pública para iniciar o formulário de adição."""
        self._abrir_form_midia()

    def _abrir_form_midia(self, id_midia=None):
        """Função privada que constrói o formulário para Adição ou Edição."""
        
        is_editing = id_midia is not None
        midia = MIDIA_MANAGER.buscar_classe_por_id(id_midia) if is_editing else None
        
        janela_form = tk.Toplevel(self.master)
        janela_form.title("Editar Mídia" if is_editing else "Adicionar Mídia")
        
        # Frame para os campos específicos (isolamento visual)
        self.campos_especificos_frame = tk.Frame(janela_form)
        
        # --- Layout Principal do Formulário ---
        row_idx = 0
        
        # 0. ID (Apenas Edição)
        if is_editing:
            tk.Label(janela_form, text=f"ID: {midia._id}", font='TkDefaultFont 10 bold').grid(row=row_idx, column=0, columnspan=2, padx=10, pady=5)
            row_idx += 1
            
        # 1. Tipo (Combobox)
        tipo_inicial = midia.__class__.__name__ if is_editing and midia else "Livro"
        tk.Label(janela_form, text="Tipo:").grid(row=row_idx, column=0, padx=10, pady=5, sticky='w')
        
        self.tipo_var.set(tipo_inicial) 
        tipos = ["Livro", "Revista", "Filme"]
        
        self.combo_tipo = ttk.Combobox(janela_form, textvariable=self.tipo_var, values=tipos, state="readonly" if is_editing else "enabled")
        self.combo_tipo.grid(row=row_idx, column=1, padx=10, pady=5, sticky='ew')
        self.tipo_var.trace_add("write", lambda *args: self.reconstruir_campos_especificos(janela_form, midia))
        row_idx += 1

        # 2. Título
        tk.Label(janela_form, text="Título:").grid(row=row_idx, column=0, padx=10, pady=5, sticky='w')
        self.inputs['titulo'] = tk.Entry(janela_form)
        self.inputs['titulo'].insert(0, midia.titulo if is_editing and midia else "")
        self.inputs['titulo'].grid(row=row_idx, column=1, padx=10, pady=5, sticky='ew')
        row_idx += 1
        
        # 3. Ano de Publicação
        tk.Label(janela_form, text="Ano:").grid(row=row_idx, column=0, padx=10, pady=5, sticky='w')
        self.inputs['ano_publicacao'] = tk.Entry(janela_form)
        self.inputs['ano_publicacao'].insert(0, midia.ano_publicacao if is_editing and midia else "")
        self.inputs['ano_publicacao'].grid(row=row_idx, column=1, padx=10, pady=5, sticky='ew')
        row_idx += 1
        
        # 4. Inserção do Frame de Campos Específicos
        self.campos_especificos_frame.grid(row=row_idx, column=0, columnspan=2, padx=10, pady=5, sticky='ew')
        row_idx += 1
        
        # --- Chamada Inicial dos Campos Específicos ---
        self.reconstruir_campos_especificos(janela_form, midia)


        # 5. Botão de Ação Final (CREATE/UPDATE)
        acao_funcao = lambda: self.salvar_midia_gui(janela_form, id_midia)
        
        tk.Button(janela_form, text="Salvar Alterações" if is_editing else "Adicionar", 
                  command=acao_funcao).grid(row=row_idx, column=1, pady=10, padx=10, sticky='e')
        
        # Garante que a coluna de inputs se expanda
        janela_form.grid_columnconfigure(1, weight=1)
        
    def reconstruir_campos_especificos(self, master, midia: ItemDeMidia | None):
        """Limpa e recria os campos específicos, aplicando o layout grid."""
        
        for widget in self.campos_especificos_frame.winfo_children():
            widget.destroy()
            
        # Limpa a referência dos inputs específicos antigos
        for key in ['autor', 'editora', 'edicao', 'diretor', 'nacionalidade']:
            if key in self.inputs:
                del self.inputs[key]

        tipo = self.tipo_var.get()
        is_editing_and_matches = midia is not None and midia.__class__.__name__ == tipo
        
        # Título do grupo
        ttk.Label(self.campos_especificos_frame, text=f"Detalhes do {tipo}:", font='TkDefaultFont 10 bold').grid(row=0, column=0, columnspan=2, pady=(5, 10), sticky='w')

        row_idx = 1
        
        # [LIVRO]
        if tipo == "Livro":
            tk.Label(self.campos_especificos_frame, text="Autor:").grid(row=row_idx, column=0, padx=5, pady=2, sticky='w')
            self.inputs['autor'] = tk.Entry(self.campos_especificos_frame)
            if is_editing_and_matches: self.inputs['autor'].insert(0, midia.autor)
            self.inputs['autor'].grid(row=row_idx, column=1, padx=5, pady=2, sticky='ew')
            
        # [REVISTA]
        elif tipo == "Revista":
            tk.Label(self.campos_especificos_frame, text="Editora:").grid(row=row_idx, column=0, padx=5, pady=2, sticky='w')
            self.inputs['editora'] = tk.Entry(self.campos_especificos_frame)
            if is_editing_and_matches: self.inputs['editora'].insert(0, midia.editora)
            self.inputs['editora'].grid(row=row_idx, column=1, padx=5, pady=2, sticky='ew')
            row_idx += 1
            
            tk.Label(self.campos_especificos_frame, text="Edição:").grid(row=row_idx, column=0, padx=5, pady=2, sticky='w')
            self.inputs['edicao'] = tk.Entry(self.campos_especificos_frame)
            if is_editing_and_matches: self.inputs['edicao'].insert(0, midia.edicao)
            self.inputs['edicao'].grid(row=row_idx, column=1, padx=5, pady=2, sticky='ew')

        # [FILME]
        elif tipo == "Filme":
            tk.Label(self.campos_especificos_frame, text="Diretor:").grid(row=row_idx, column=0, padx=5, pady=2, sticky='w')
            self.inputs['diretor'] = tk.Entry(self.campos_especificos_frame)
            if is_editing_and_matches: self.inputs['diretor'].insert(0, midia.diretor)
            self.inputs['diretor'].grid(row=row_idx, column=1, padx=5, pady=2, sticky='ew')
            row_idx += 1
            
            tk.Label(self.campos_especificos_frame, text="Nacionalidade:").grid(row=row_idx, column=0, padx=5, pady=2, sticky='w')
            self.inputs['nacionalidade'] = tk.Entry(self.campos_especificos_frame)
            if is_editing_and_matches: self.inputs['nacionalidade'].insert(0, midia.nacionalidade)
            self.inputs['nacionalidade'].grid(row=row_idx, column=1, padx=5, pady=2, sticky='ew')
            
        self.campos_especificos_frame.grid_columnconfigure(1, weight=1)

    def salvar_midia_gui(self, janela_form, id_editar=None):
        """Função que coleta dados e chama o MODELO para Adição ou Edição."""
        
        try:
            titulo = self.inputs['titulo'].get()
            ano = int(self.inputs['ano_publicacao'].get())
            tipo = self.tipo_var.get()
            
            midia = None
            
            # Helper para obter o texto do input, lidando com entradas vazias (se o campo não for renderizado)
            def get_input(key):
                # Retorna o texto do Entry, ou uma string vazia se o widget não foi criado
                return self.inputs.get(key, tk.Entry(janela_form)).get()

            # 1. Cria o objeto Midia
            if tipo == "Livro":
                midia = Livro(titulo, ano, get_input('autor'), id_editar)
            elif tipo == "Revista":
                midia = Revista(titulo, ano, get_input('editora'), get_input('edicao'), id_editar)
            elif tipo == "Filme":
                midia = Filme(titulo, ano, get_input('diretor'), get_input('nacionalidade'), id_editar)
            
            if not midia: raise ValueError("Tipo de mídia inválido.")

            # 2. Chama a lógica do Gerenciador (MODELO)
            if id_editar:
                if MIDIA_MANAGER.atualizar_item(midia):
                    messagebox.showinfo("Sucesso", f"'{titulo}' (ID: {midia._id}) atualizado!")
                else:
                    messagebox.showerror("Erro de Atualização", "Falha ao atualizar a mídia. Verifique a validação.")
            else:
                if MIDIA_MANAGER.adicionar_item(midia):
                    messagebox.showinfo("Sucesso", f"'{titulo}' adicionado à coleção!")
                else:
                    messagebox.showerror("Erro de Validação", "Verifique se o Título e o Ano são válidos.")
            
            janela_form.destroy() 
            self.atualizar_lista() 
            
        except ValueError:
            messagebox.showerror("Erro de Entrada", "O ano deve ser um número inteiro, ou campos obrigatórios estão vazios.")
        except Exception as e:
            messagebox.showerror("Erro Desconhecido", f"Ocorreu um erro: {e}")


# --- Inicia a Aplicação ---
if __name__ == "__main__":
    root = tk.Tk()
    app = GerenciadorGUI(root)
    
    # Salva a coleção ao fechar a janela principal
    root.protocol("WM_DELETE_WINDOW", lambda: [MIDIA_MANAGER.salvar_colecao_manualmente(), root.destroy()]) 
    
    root.mainloop()