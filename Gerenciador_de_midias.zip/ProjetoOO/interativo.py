from package.models.modelos import ItemDeMidia, ValidadorDeDados, Filme, Revista, Livro
from package.controller.gerenciador import GerenciadorDeMidia



def adicionando_midia(gerenciador):
    print("\n === Adicionando uma nova midia ===")


    tipo = input("Que tipo de midia quer adicionar? (Livro/Revista/Filme):").lower()
    
    if tipo not in ["livro", "revista", "filme"]:
        print("\n Escolha uma midia válida")
        return

    titulo = input("Qual o título?")

    try:
        ano = int(input("Qual o ano de publicação?"))
    except ValueError:
        print("\n O ano deve ser um número inteiro")
        return

    midia = None

    if tipo == "livro":
        autor = input("Quem é o autor da obra?")
        midia = Livro(titulo, ano, autor)
    
    elif tipo == "filme":
        diretor = input("Quem é o diretor?")
        nacionalidade = input("Qual a nacionalidade do filme?")
        midia = Filme(titulo, ano, diretor, nacionalidade)

    elif tipo == "revista":
        editora = input("Qual a editora?")
        edicao = input("Qual a edição?")
        midia = Revista(titulo, ano, editora, edicao)

    if midia:
        if gerenciador.adicionar_item(midia):
            print(f"\n {midia.titulo} ({midia.ano_publicacao}, ID: {midia._id}) agora faz parte da lista!!!") 


def menu():
    gerenciadorobj = GerenciadorDeMidia()

    while True:
        print("\n ===========")
        print("Menu principal")
        print("===========")
        print("[1] Adicionar mídia")
        print("[2] Listar mídias")
        print("[3] Remover mídia (ID)")
        print("[4] Buscar mídias")
        print("[5] Fechar menu")

        acao = input("O que deseja fazer?")

        if acao == "1":
            adicionando_midia(gerenciadorobj)
        

        elif acao == "2":
            gerenciadorobj.get_colecao()
        

        elif acao == "3":
            id_midia = input("\n Digite o ID para remover a mídia")

            if gerenciadorobj.remover_item(id_midia):
                print("\nMídia removida")
            else:
                print(f"\nNenhuma mídia com o ID {id_midia} foi encontrada")
        

        elif acao == "4":
            print("[1] Buscar mídias por título")
            print("[2] Buscar informações da mídia por ID")
            escolha_da_busca = input(" O que deseja fazer?")

            if escolha_da_busca == "1":
                titulo_input = input("Qual o título da mídia?")
                gerenciadorobj.buscar_por_titulo(titulo_input)
            elif escolha_da_busca == "2":
                id = input("Qual a id da mídia?")

            
                info = gerenciadorobj.get_info_id(id)
                print("\nInformações")
                print(info)

                midia = gerenciadorobj.buscar_classe_por_id(id)

                if isinstance(midia, (Livro, Revista)):
                    pergunta = "lido"
                elif isinstance(midia, (Filme)):
                    pergunta = "visto"


                if not midia.esta_consumido():
                    print("[1] Sim")
                    print("[2] Nao")
                    marcar_lida = input(f"Deseja marcar como {pergunta}?")
                
                    if marcar_lida == "1":
                        midia.marcar_como_lido()
                        print(f"\nMarcado como {pergunta}")
                    elif marcar_lida == "2":
                        print("\n Retornando ao menu principal")
                    else:
                        print("\nResposta inválida, retornando ao menu")

            else:
                print("\nResposta inválida, retornando ao menu")


        elif acao == "5":
            print("\nEncerrando")
            gerenciadorobj.salvar_colecao_manualmente()
            break
        
        else:
            print("\nOpção inválida")

if __name__ == "__main__":
    menu()



